<ol class="breadcrumb">
    <li><a href="#"><i class="demo-pli-home"></i></a></li>
    <li><a href="#">Pages</a></li>
    <li class="active">Blank page</li>
</ol>