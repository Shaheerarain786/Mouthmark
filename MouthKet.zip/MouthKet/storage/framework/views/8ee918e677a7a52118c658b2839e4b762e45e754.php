<footer id="footer">

</footer>   <?php /**PATH /Users/shaheerarain/Documents/GitHub/MouthKet/resources/views/layouts/footer.blade.php ENDPATH**/ ?>