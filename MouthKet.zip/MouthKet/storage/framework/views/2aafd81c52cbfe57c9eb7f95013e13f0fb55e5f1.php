<footer id="footer">

</footer>   <?php /**PATH C:\Users\Wangard\Documents\Github\MouthKet\resources\views/layouts/footer.blade.php ENDPATH**/ ?>