<?php $__env->startSection('PageTitle', 'Dashboard'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href=""><i class="demo-pli-home"></i></a></li>
    <li><a href="">Dashboard</a></li>
<?php $__env->stopSection(); ?>
<style>
    #tasks p {
        color: white !important;
    }
    #page-head p,h3 {
        color:white !important;
    }
    #page-content h3{
        color:black !important;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div id="page-head">

        <div class="pad-all text-center">
            <h3>Welcome back to the <strong>Mouthmark</strong></h3>
            <p>Scroll down to see quick links and overviews of your website<p></p>
            </div>
    </div>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div id="page-content">
                        <h3>TASKS</h3>
                        <hr>
                        <div id="tasks" class="row">
                            <div class="col-md-2">
                                <div style="background: #000 !important;"
                                     class="panel panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['today']); ?></p>
                                        <strong><p class="mar-no">Today</p></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel panel-primary panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['total']); ?></p>
                                        <strong><p class="mar-no">Total Tasks</p></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel panel-warning panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['tasks_pending']); ?></p>
                                        <strong><p class="mar-no">Pending</p></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel panel-success panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['task_approved']); ?></p>
                                        <strong><p class="mar-no">Approved</p></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel panel-info panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['task_completed']); ?></p>
                                        <strong><p class="mar-no">Completed</p></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel panel-danger panel-colorful media middle pad-all">
                                    <div class="media-left">
                                        <div class="pad-hor">
                                            <i class="fa fa-flag icon-2x"></i>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <p class="text-2x mar-no text-semibold"><?php echo e($tasks_count['task_discard']); ?></p>
                                        <strong><p class="mar-no">Discard</p></strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h3>USERS</h3>
                        <hr>
                        <div id="tasks" class="row">
                            <div class="col-md-4">
                                <div class="panel panel-success panel-colorful">
                                    <div class="pad-all">
                                        <p class="text-lg text-bold"><i class="fa fa-user"></i> USERS</p>
                                        <p class="mar-no text-bold">
                                            <span class="pull-right text-bold"><?php echo e($users); ?></span> Total Users
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span class="pull-right text-bold"><?php echo e($super_admins); ?></span> Total
                                            Superadmins
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span class="pull-right text-bold"><?php echo e($admins); ?></span> Total Admins
                                        </p>
                                    </div>
                                    <div class="pad-top text-center">
                                        <!--Placeholder-->
                                        <div id="demo-sparkline-area" class="sparklines-full-content">
                                            <canvas width="240" height="60"
                                                    style="display: inline-block; width: 240px; height: 60px; vertical-align: top;"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-info panel-colorful">
                                    <div class="pad-all">
                                        <p class="text-lg text-bold"><i class="demo-pli-data-storage icon-fw"></i>
                                            ADVERTISERS</p>
                                        <p class="mar-no text-bold">
                                            <span class="pull-right text-bold"><?php echo e($advertiser_count['total']); ?></span>
                                            Total
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span
                                                class="pull-right text-bold"><?php echo e($advertiser_count['adv_approved']); ?></span>
                                            Approved
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span
                                                class="pull-right text-bold"><?php echo e($advertiser_count['adv_pending']); ?></span>
                                            Pending
                                        </p>
                                    </div>
                                    <div class="pad-top text-center">
                                        <!--Placeholder-->
                                        <div id="demo-sparkline-area" class="sparklines-full-content">
                                            <canvas width="240" height="60"
                                                    style="display: inline-block; width: 240px; height: 60px; vertical-align: top;"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel panel-dark panel-colorful">
                                    <div class="pad-all">
                                        <p class="text-lg text-bold"><i class="demo-pli-data-storage icon-fw"></i>
                                            INFLUENCERS</p>
                                        <p class="mar-no text-bold">
                                            <span class="pull-right text-bold"><?php echo e($influencer_count['total']); ?></span>
                                            Approved
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span
                                                class="pull-right text-bold"><?php echo e($influencer_count['inf_approved']); ?></span>
                                            Approved
                                        </p>
                                        <p class="mar-no text-bold">
                                            <span
                                                class="pull-right text-bold"><?php echo e($influencer_count['inf_pending']); ?></span>
                                            Pending
                                        </p>
                                    </div>
                                    <div class="pad-top text-center">
                                        <!--Placeholder-->
                                        <div id="demo-sparkline-area" class="sparklines-full-content">
                                            <canvas width="240" height="60"
                                                    style="display: inline-block; width: 240px; height: 60px; vertical-align: top;"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        

                        
                        
                        
                        
                        
                        

                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        
                        

                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaheerarain/Documents/GitHub/MouthKet/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>