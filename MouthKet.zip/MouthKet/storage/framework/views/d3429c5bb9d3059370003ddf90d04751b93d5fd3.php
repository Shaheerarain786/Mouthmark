<?php $__env->startSection('PageTitle', 'Dashboard'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href=""><i class="demo-pli-home"></i></a></li>
    <li><a href="">Dashboard</a></li>
    <li class="active">Admin</li>
<?php $__env->stopSection(); ?>
<style>
    th {
        color: white !important;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wangard\Documents\Github\MouthKet\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>