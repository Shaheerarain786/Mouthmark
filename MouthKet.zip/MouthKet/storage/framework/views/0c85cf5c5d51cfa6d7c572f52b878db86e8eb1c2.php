<?php $__env->startSection('pageTitle', 'Admins'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(url('admin')); ?>"><i class="demo-pli-home"></i></a></li>
    <li><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
    <li class="active">Permissions</li>
<?php $__env->stopSection(); ?>
<style>
</style>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Assign Permissions</h3>
                    </div>

                    <?php if(session()->has("error")): ?>
                        <div class="alert alert-danger">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("error")); ?></stong>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("success")); ?></stong>
                        </div>
                    <?php endif; ?>

                    <div class="panel-body">
                        <div class="panel">
                            <div class="panel-body">
                                <form method="POST" action="<?php echo e(url('assign-permissions/')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-check">
                                        <input id="select_all" class="form-check-input checkbox" type="checkbox" value="">
                                        <label class="form-check-label" for="defaultCheck1">
                                            Select All
                                        </label>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input class="form-check-input checkbox" type="checkbox" value="<?php echo e($per->id); ?>"
                                                   id="defaultCheck1">
                                            <label class="form-check-label" for="defaultCheck1">
                                                <?php echo e($per->name); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <button type="submit">Assign</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#select_all').on('click', function () {
            if (this.checked) {
                $('.checkbox').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox').each(function () {
                    this.checked = false;
                });
            }
        });

        $('.checkbox').on('click', function () {
            if ($('.checkbox:checked').length == $('.checkbox').length) {
                $('#select_all').prop('checked', true);
            } else {
                $('#select_all').prop('checked', false);
            }
        });
    });
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaheerarain/Documents/GitHub/MouthKet/resources/views/admin/permissions/index.blade.php ENDPATH**/ ?>