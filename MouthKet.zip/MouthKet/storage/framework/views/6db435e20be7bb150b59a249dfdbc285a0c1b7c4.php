
<?php $__env->startSection('pageTitle', 'Create Admin'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(url('admin')); ?>"><i class="demo-pli-home"></i></a></li>
    <li><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
    <li><a href="<?php echo e(url('admin/admins')); ?>"> Admin</a></li>
    <li class="active">Create</li>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Manage Admin</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('admins.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-sm-3 control-label" for="demo-hor-inputemail">Username<span
                                                style="color:red">*</span></label>
                                    <div class="col-sm-9">
                                        <input type="text" name="username" required placeholder="Username" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label" for="demo-hor-inputemail">Email <span
                                                style="color:red">*</span></label>
                                    <div class="col-sm-9">
                                        <input type="email" name="email" required placeholder="Email"
                                               id="demo-hor-inputemail" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label" for="demo-hor-inputemail">Role <span
                                                style="color:red">*</span></label>
                                    <div class="col-sm-9">
                                        <select class="form-control" name="role_id" id="roles">
                                            <option disabled selected value="">Select Role</option>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label" for="demo-hor-inputpass">Password <span
                                                style="color:red">*</span></label>
                                    <div class="col-sm-9">
                                        <input type="password" name="password" required placeholder="Password"
                                               id="demo-hor-inputpass" class="form-control">
                                    </div>
                                </div>

                                <div class="col-sm-offset-3 col-sm-9">
                                    <button class="btn btn-success" type="submit">Create</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    $(document).ready(function () {
        $("#roles").select2();
    })

</script>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaheerarain/Documents/GitHub/MouthKet/resources/views/admin/admins/create.blade.php ENDPATH**/ ?>