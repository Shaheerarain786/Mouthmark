<?php $__env->startSection('pageTitle', 'Admins'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(url('admin')); ?>"><i class="demo-pli-home"></i></a></li>
    <li><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
    <li class="active">Advertiser</li>
<?php $__env->stopSection(); ?>
<style>
</style>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Manage Advertiser</h3>
                    </div>
                    <?php if(session()->has("error")): ?>
                        <div class="alert alert-danger">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("error")); ?></stong>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("success")); ?></stong>
                        </div>
                    <?php endif; ?>

                    <div class="panel-body">
                        <div class="panel">
                            <div class="panel-body">
                                <table id="demo-dt-selection" class="table table-striped table-bordered" cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th class="min-tablet">Full Name</th>
                                        <th class="min-tablet">Type</th>
                                        <th class="min-tablet">Status</th>
                                        <th class="min-desktop">Details</th>
                                        <th class="min-desktop">Delete</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $inf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i->full_name); ?></td>
                                            <td><?php echo e($i->type); ?></td>
                                            <td>
                                                <?php if($i->account_status == "pending"): ?>
                                                    <kbd>Pending</kbd>
                                                <?php endif; ?>
                                                <?php if($i->account_status == "approved"): ?>
                                                    <kbd style="background-color: limegreen">Approved</kbd>
                                                <?php endif; ?>
                                                <?php if($i->account_status == "rejected"): ?>
                                                    <kbd style="background-color: red">Rejected</kbd>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-success"
                                                   href="<?php echo e(url('users/advertiser/'. $i->id . '/edit/')); ?>"><i
                                                            class="fa fa-edit"></i></a>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(url('users/advertiser/discard/'.$i->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button class="btn btn-danger" type="submit"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



































                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wangard\Documents\Github\MouthKet\resources\views/admin/advertiser/index.blade.php ENDPATH**/ ?>