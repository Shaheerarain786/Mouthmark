<?php $__env->startSection('pageTitle', 'Admins'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(url('/')); ?>"><i class="demo-pli-home"></i></a></li>
    <li><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
    <li class="active">Admin</li>
<?php $__env->stopSection(); ?>
<style>
</style>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Manage Admins</h3>
                    </div>
                    <?php if(session()->has("error")): ?>
                        <div class="alert alert-danger">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("error")); ?></stong>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <button class="close" data-dismiss="alert"><i class="pci-cross pci-circle"></i></button>
                            <stong><?php echo e(session()->get("success")); ?></stong>
                        </div>
                    <?php endif; ?>

                    <div class="panel-body">
                        <a href="<?php echo e(url('admins/create')); ?>">
                            <button type="button" class="btn  btn-dark">ADD ADMIN</button>
                        </a>
                        <div class="panel">
                            <div class="panel-body">
                                <table id="demo-dt-selection" class="table table-striped table-bordered" cellspacing="0"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th>User Name</th>
                                        <th class="min-tablet">Email</th>
                                        <th class="min-tablet">Role</th>
                                        <th class="min-desktop">Edit</th>
                                        <th class="min-desktop">Delete</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($admin->username); ?></td>
                                            <td><?php echo e($admin->email); ?></td>
                                            <td><?php echo e($admin->roles->role); ?></td>
                                            <td>
                                                <a class="btn btn-success"
                                                   href="<?php echo e(url('admins/'. $admin->id . '/edit/')); ?>"><i
                                                            class="fa fa-edit"></i></a>
                                            </td>
                                            <td>
                                                <button class="btn btn-danger"
                                                        <?php if(auth()->user()->id == $admin->id): ?> disabled
                                                        <?php endif; ?> data-toggle="modal" data-target="#<?php echo e($admin->id); ?>"><i
                                                            class="fas fa-trash-alt"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="modal fade" id="<?php echo e($admin->id); ?>" tabindex="-1" role="dialog"
                             aria-labelledby="exampleModalLabel"
                             aria-hidden="true">
                            <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
                                <!--Content-->
                                <div class="modal-content text-center">
                                    <!--Header-->
                                    <div class="modal-header d-flex justify-content-center">
                                        <h5 class="heading">Are you sure you want to delete <span
                                                    class="text-success"><?php echo e($admin->name); ?></span></h5>
                                    </div>

                                    <!--Body-->
                                    <div class="modal-body">

                                        <i style="color:red;" class="fas fa-times fa-4x animated rotateIn"></i>

                                    </div>

                                    <!--Footer-->
                                    <div class="modal-footer flex-center">
                                        <form method="POST" action="<?php echo e(url('admins/' . $admin->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a type="button" class="btn" data-dismiss="modal">No</a>
                                            <button type="submit" class="btn btn-danger waves-effect">Yes</button>

                                        </form>
                                    </div>
                                </div>
                                <!--/.Content-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shaheerarain/Documents/GitHub/MouthKet/resources/views/admin/admins/index.blade.php ENDPATH**/ ?>