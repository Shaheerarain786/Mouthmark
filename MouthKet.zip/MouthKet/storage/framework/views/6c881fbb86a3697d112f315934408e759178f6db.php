<?php $__env->startSection('pageTitle', 'Edit Admin'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(url('admin')); ?>"><i class="demo-pli-home"></i></a></li>
    <li><a href="<?php echo e(url('admin')); ?>">Dashboard</a></li>
    <li><a href="<?php echo e(url('admin/admins')); ?>"> Admin</a></li>
    <li class="active">Update</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bordered">
                    <div class="panel-heading">
                        <h3 class="panel-title">Manage Admin</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(url('roles/' . $role->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-sm-3 control-label" for="demo-hor-inputemail">Role <span style="color:red">*</span></label>
                                    <div class="col-sm-9">
                                        <input type="text" name="role" placeholder="Role" class="form-control" value="<?php echo e($role->role); ?>">
                                    </div>
                                </div>

                                <div class="col-sm-offset-3 col-sm-9">
                                    <button class="btn btn-success" type="submit">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wangard\Documents\Github\MouthKet\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>