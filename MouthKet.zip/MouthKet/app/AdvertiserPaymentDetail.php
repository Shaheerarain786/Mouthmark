<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertiserPaymentDetail extends Model
{
    //
}
